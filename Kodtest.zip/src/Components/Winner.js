import React from "react"

export default function Winner(){
    return(
        <div className={"winner_text"}>
            <h1>You win, gz!</h1>
        </div>
    )
}